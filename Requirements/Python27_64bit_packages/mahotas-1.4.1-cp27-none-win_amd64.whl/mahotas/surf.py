import warnings
warnings.warn(
'''Use

from mahotas.features import surf
''', DeprecationWarning)

from mahotas.features.surf import *
